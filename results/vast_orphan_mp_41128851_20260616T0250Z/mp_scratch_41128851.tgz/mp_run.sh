export HF_TOKEN=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 PATH=/root/v/bin:$PATH PYTHONPATH=/root/flashinfer
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True VLLM_FLASHINFER_MM_PREFIX=1 VLLM_NVFP4_KV_VOSPLIT=1 VLLM_NVFP4_KV_LINEAR_V_SF=1
M=google/gemma-4-26b-a4b-it
cd /root
[ -f wikitext_8k.txt ] || python corpus_fetch.py > corpus.log 2>&1
C="--model $M --tokenizer $M --corpus wikitext_8k.txt --ctx 8185 --prefix-len 4096 --max-model-len 8192 --max-num-batched-tokens 4096 --skip-warmup --gpu-memory-utilization 0.85 --enforce-eager"
gpufree(){ for i in 1 2 3 4 5; do u=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits); [ "$u" -lt 2000 ] && return; sleep 5; done; }
echo "=== MIXED-PRECISION 26B (HF truth=7.9923) ===" > /root/mp_result.txt
gpufree; python vllm_matched_kv_anchor.py $C --kv-cache-dtype auto --output mp_bf16.json > mp_bf16.log 2>&1
echo "bf16:            $(grep -oE \"mean_nll_nats..: [0-9.]*\" mp_bf16.json|head -1)" >> /root/mp_result.txt
pkill -9 -f EngineCore; sleep 4; gpufree
VLLM_NVFP4_KV_CALIB=/root/calib_kv01.json python vllm_matched_kv_anchor.py $C --kv-cache-dtype nvfp4 --output mp_nvfp4.json > mp_nvfp4.log 2>&1
echo "nvfp4 all:       $(grep -oE \"mean_nll_nats..: [0-9.]*\" mp_nvfp4.json|head -1)" >> /root/mp_result.txt
pkill -9 -f EngineCore; sleep 4; gpufree
VLLM_NVFP4_KV_CALIB=/root/calib_kv01.json python vllm_matched_kv_anchor.py $C --kv-cache-dtype nvfp4 --kv-cache-dtype-skip-layers 0=fp8_e4m3 1=fp8_e4m3 2=fp8_e4m3 3=fp8_e4m3 4=fp8_e4m3 --output mp_mix.json > mp_mix.log 2>&1
echo "nvfp4 +L0-4 fp8: $(grep -oE \"mean_nll_nats..: [0-9.]*\" mp_mix.json|head -1)" >> /root/mp_result.txt
echo DONE_MP >> /root/mp_result.txt
